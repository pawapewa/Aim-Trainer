import random
import math
from constants import WIDTH, HEIGHT, TARGET_COLORS

class TargetCircle:
    def __init__(self, radius):
        self.r = radius
        self.x = random.randint(self.r, WIDTH - self.r)
        self.y = random.randint(self.r + 50, HEIGHT - self.r)
        self.color = random.choice(TARGET_COLORS)

class TrackingTarget:
    def __init__(self, radius, speed):
        self.r = radius
        self.x = WIDTH // 2
        self.y = HEIGHT // 2
        angle = random.uniform(0, 2 * math.pi)
        self.dx = math.cos(angle) * speed
        self.dy = math.sin(angle) * speed
        self.color = TARGET_COLORS[0]

    def update(self):
        self.x += self.dx
        self.y += self.dy
        if self.x - self.r < 0 or self.x + self.r > WIDTH:
            self.dx *= -1
            self.x = max(self.r, min(self.x, WIDTH - self.r))
        if self.y - self.r < 50 or self.y + self.r > HEIGHT:
            self.dy *= -1
            self.y = max(self.r + 50, min(self.y, HEIGHT - self.r))