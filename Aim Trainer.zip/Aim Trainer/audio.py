import pygame
import math
import array

pygame.mixer.pre_init(44100, -16, 2, 512)
pygame.mixer.init()

def generate_beep(freq, duration_ms, volume_level=1.0):
    sample_rate = 44100
    n_samples = int(sample_rate * (duration_ms / 1000.0))
    buf = array.array('h')
    max_amp = int(32767 * volume_level)
    for i in range(n_samples):
        t = float(i) / sample_rate
        val = int(max_amp * math.sin(2 * math.pi * freq * t))
        buf.append(val)
        buf.append(val)
    try:
        return pygame.mixer.Sound(buffer=buf)
    except Exception:
        class DummySound:
            def play(self): pass
            def set_volume(self, v): pass
        return DummySound()

sound_hit = generate_beep(880, 100)
sound_miss = generate_beep(220, 200)

def set_system_volume(volume):
    sound_hit.set_volume(volume)
    sound_miss.set_volume(volume)