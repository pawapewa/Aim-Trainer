import pygame
from constants import BTN_COLOR, BTN_HOVER_COLOR, TEXT_COLOR

class Button:
    def __init__(self, x, y, w, h, text, action=None, color=BTN_COLOR):
        self.rect = pygame.Rect(x, y, w, h)
        self.text = text
        self.action = action
        self.color = color

    def draw(self, surface, font):
        mouse_pos = pygame.mouse.get_pos()
        current_color = BTN_HOVER_COLOR if self.rect.collidepoint(mouse_pos) else self.color
        pygame.draw.rect(surface, current_color, self.rect, border_radius=8)
        
        text_surf = font.render(self.text, True, TEXT_COLOR)
        text_rect = text_surf.get_rect(center=self.rect.center)
        surface.blit(text_surf, text_rect)

    def is_clicked(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos):
                if self.action:
                    self.action()
                return True
        return False