import json
import os
from constants import RESULTS_FILE

def load_results():
    if os.path.exists(RESULTS_FILE):
        try:
            with open(RESULTS_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"Ошибка загрузки результатов: {e}")
            return []
    return []

def save_results_to_file(results_db):
    try:
        with open(RESULTS_FILE, 'w', encoding='utf-8') as f:
            json.dump(results_db, f, ensure_ascii=False, indent=4)
    except Exception as e:
        print(f"Ошибка сохранения результатов: {e}")