import pygame
import sys
import math
import constants as const
import storage
import audio
from entities import TargetCircle, TrackingTarget
from ui import Button

pygame.init()

screen = pygame.display.set_mode((const.WIDTH, const.HEIGHT))
pygame.display.set_caption("Aim Trainer & Tracker")
clock = pygame.time.Clock()

font_large = pygame.font.SysFont("segoeui", 54, bold=True)
font_medium = pygame.font.SysFont("segoeui", 32)
font_small = pygame.font.SysFont("segoeui", 24)

state = "MENU"
mode = ""
difficulty = ""
volume = 0.5

res_filter_mode = ""
res_filter_diff = ""

score = 0.0
start_time = 0
pause_start_time = 0
targets = []
tracking_target = None
player_name = ""
results_db = storage.load_results()

def set_state(new_state):
    global state
    state = new_state

def open_results():
    global res_filter_mode, res_filter_diff
    res_filter_mode = ""
    res_filter_diff = ""
    set_state("RESULTS")

def go_back_results():
    global res_filter_mode, res_filter_diff
    if res_filter_diff != "":
        res_filter_diff = ""
    elif res_filter_mode != "":
        res_filter_mode = ""
    else:
        set_state("MENU")

def set_res_mode(m):
    global res_filter_mode
    res_filter_mode = m

def set_res_diff(d):
    global res_filter_diff
    res_filter_diff = d

def vol_up():
    global volume
    volume = min(1.0, volume + 0.1)
    audio.set_system_volume(volume)

def vol_down():
    global volume
    volume = max(0.0, volume - 0.1)
    audio.set_system_volume(volume)

def select_mode(m):
    global mode
    mode = m
    set_state("DIFF_SELECT")

def select_diff(d):
    global difficulty
    difficulty = d
    start_game()

def start_game():
    global score, start_time, targets, tracking_target
    score = 0.0
    start_time = pygame.time.get_ticks()
    
    if mode == "CLICKER":
        targets = [TargetCircle(const.CLICKER_RADIUS[difficulty]) for _ in range(4)]
        set_state("GAME_CLICKER")
    else:
        tracking_target = TrackingTarget(20, const.TRACKING_SPEED[difficulty])
        set_state("GAME_TRACKING")

def pause_game():
    global pause_start_time
    pause_start_time = pygame.time.get_ticks()
    set_state("PAUSE")

def resume_game():
    global start_time
    start_time += (pygame.time.get_ticks() - pause_start_time)
    set_state("GAME_CLICKER" if mode == "CLICKER" else "GAME_TRACKING")

def end_game():
    global player_name
    player_name = ""
    set_state("GAME_OVER")

def save_result():
    if player_name.strip():
        results_db.append({
            "name": player_name,
            "score": int(score),
            "mode": "Кликер" if mode == "CLICKER" else "Трекинг",
            "diff": difficulty
        })
        storage.save_results_to_file(results_db)
    set_state("MENU")

btn_play = Button(const.WIDTH//2 - 100, 170, 200, 50, "Играть", lambda: set_state("MODE_SELECT"))
btn_results = Button(const.WIDTH//2 - 100, 240, 200, 50, "Результаты", open_results)
btn_settings = Button(const.WIDTH//2 - 100, 310, 200, 50, "Настройки", lambda: set_state("SETTINGS"))
btn_exit = Button(const.WIDTH//2 - 100, 380, 200, 50, "Выход", sys.exit, const.DANGER_COLOR)

btn_vol_minus = Button(const.WIDTH//2 - 150, 250, 50, 50, "-")
btn_vol_plus = Button(const.WIDTH//2 + 100, 250, 50, 50, "+")
btn_back = Button(const.WIDTH//2 - 100, 400, 200, 50, "Назад", lambda: set_state("MENU"))

btn_mode_clicker = Button(const.WIDTH//2 - 150, 200, 300, 50, "Режим 1: Кликер", lambda: select_mode("CLICKER"))
btn_mode_tracking = Button(const.WIDTH//2 - 150, 280, 300, 50, "Режим 2: Трекинг", lambda: select_mode("TRACKING"))

diff_buttons = [
    Button(const.WIDTH//2 - 100, 140, 200, 50, "Лёгкий", lambda: select_diff("Лёгкий")),
    Button(const.WIDTH//2 - 100, 210, 200, 50, "Средний", lambda: select_diff("Средний")),
    Button(const.WIDTH//2 - 100, 280, 200, 50, "Сложный", lambda: select_diff("Сложный")),
    Button(const.WIDTH//2 - 100, 350, 200, 50, "Эксперт", lambda: select_diff("Эксперт"), const.DANGER_COLOR)
]
btn_diff_back = Button(const.WIDTH//2 - 100, 440, 200, 50, "Назад", lambda: set_state("MODE_SELECT"))

btn_res_clicker = Button(const.WIDTH//2 - 150, 200, 300, 50, "Режим 1: Кликер", lambda: set_res_mode('Кликер'))
btn_res_tracking = Button(const.WIDTH//2 - 150, 280, 300, 50, "Режим 2: Трекинг", lambda: set_res_mode('Трекинг'))

btn_res_easy = Button(const.WIDTH//2 - 100, 140, 200, 50, "Лёгкий", lambda: set_res_diff('Лёгкий'))
btn_res_medium = Button(const.WIDTH//2 - 100, 210, 200, 50, "Средний", lambda: set_res_diff('Средний'))
btn_res_hard = Button(const.WIDTH//2 - 100, 280, 200, 50, "Сложный", lambda: set_res_diff('Сложный'))
btn_res_expert = Button(const.WIDTH//2 - 100, 350, 200, 50, "Эксперт", lambda: set_res_diff('Эксперт'), const.DANGER_COLOR)

btn_back_results = Button(const.WIDTH//2 - 100, 520, 200, 50, "Назад", go_back_results)

btn_resume = Button(const.WIDTH//2 - 100, 200, 200, 50, "Продолжить", resume_game)
btn_quit_menu = Button(const.WIDTH//2 - 100, 280, 200, 50, "В меню", lambda: set_state("MENU"), const.DANGER_COLOR)

btn_save = Button(const.WIDTH//2 - 160, 350, 150, 50, "Сохранить", save_result)
btn_skip = Button(const.WIDTH//2 + 10, 350, 150, 50, "Пропустить", lambda: set_state("MENU"), const.DANGER_COLOR)

audio.set_system_volume(volume)
running = True
while running:
    screen.fill(const.BG_COLOR)
    mouse_pos = pygame.mouse.get_pos()
    
    time_left = 0
    if state in ["GAME_CLICKER", "GAME_TRACKING"]:
        elapsed = (pygame.time.get_ticks() - start_time) / 1000
        time_left = max(0, const.ROUND_TIME - elapsed)
        if time_left <= 0:
            end_game()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if state == "MENU":
            btn_play.is_clicked(event)
            btn_results.is_clicked(event)
            btn_settings.is_clicked(event)
            btn_exit.is_clicked(event)
            
        elif state == "RESULTS":
            btn_back_results.is_clicked(event)
            if res_filter_mode == "":
                btn_res_clicker.is_clicked(event)
                btn_res_tracking.is_clicked(event)
            elif res_filter_diff == "":
                btn_res_easy.is_clicked(event)
                btn_res_medium.is_clicked(event)
                btn_res_hard.is_clicked(event)
                btn_res_expert.is_clicked(event)

        elif state == "SETTINGS":
            btn_back.is_clicked(event)
            if btn_vol_minus.is_clicked(event): vol_down()
            if btn_vol_plus.is_clicked(event): vol_up()

        elif state == "MODE_SELECT":
            btn_mode_clicker.is_clicked(event)
            btn_mode_tracking.is_clicked(event)
            btn_back.is_clicked(event)

        elif state == "DIFF_SELECT":
            for btn in diff_buttons: btn.is_clicked(event)
            btn_diff_back.is_clicked(event)

        elif state == "GAME_CLICKER":
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                pause_game()
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                hit = False
                for t in reversed(targets):
                    if math.hypot(event.pos[0] - t.x, event.pos[1] - t.y) <= t.r:
                        score += 1
                        audio.sound_hit.play()
                        targets.remove(t)
                        targets.append(TargetCircle(const.CLICKER_RADIUS[difficulty]))
                        hit = True
                        break
                if not hit:
                    score -= 1
                    audio.sound_miss.play()

        elif state == "GAME_TRACKING":
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                pause_game()

        elif state == "PAUSE":
            btn_resume.is_clicked(event)
            btn_quit_menu.is_clicked(event)

        elif state == "GAME_OVER":
            btn_save.is_clicked(event)
            btn_skip.is_clicked(event)
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_BACKSPACE:
                    player_name = player_name[:-1]
                elif event.unicode.isprintable() and len(player_name) < 15:
                    player_name += event.unicode

    if state == "MENU":
        title = font_large.render("Aim Trainer", True, const.UI_COLOR)
        screen.blit(title, (const.WIDTH//2 - title.get_width()//2, 70))
        btn_play.draw(screen, font_medium)
        btn_results.draw(screen, font_medium)
        btn_settings.draw(screen, font_medium)
        btn_exit.draw(screen, font_medium)

    elif state == "RESULTS":
        if res_filter_mode == "":
            title = font_large.render("Результаты: Выбор режима", True, const.UI_COLOR)
            screen.blit(title, (const.WIDTH//2 - title.get_width()//2, 50))
            btn_res_clicker.draw(screen, font_medium)
            btn_res_tracking.draw(screen, font_medium)
            btn_back_results.rect.y = 380
            
        elif res_filter_diff == "":
            title = font_large.render("Результаты: Сложность", True, const.UI_COLOR)
            screen.blit(title, (const.WIDTH//2 - title.get_width()//2, 50))
            btn_res_easy.draw(screen, font_medium)
            btn_res_medium.draw(screen, font_medium)
            btn_res_hard.draw(screen, font_medium)
            btn_res_expert.draw(screen, font_medium)
            btn_back_results.rect.y = 440
            
        else:
            title = font_large.render(f"Топ [{res_filter_mode} - {res_filter_diff}]", True, const.UI_COLOR)
            screen.blit(title, (const.WIDTH//2 - title.get_width()//2, 40))
            
            filtered = [r for r in results_db if r['mode'] == res_filter_mode and r['diff'] == res_filter_diff]
            sorted_results = sorted(filtered, key=lambda x: x['score'], reverse=True)
            
            if not sorted_results:
                msg = font_medium.render("Рекордов в этой категории пока нет!", True, const.UI_COLOR)
                screen.blit(msg, (const.WIDTH//2 - msg.get_width()//2, 250))
            else:
                pygame.draw.line(screen, const.UI_COLOR, (150, 150), (const.WIDTH - 150, 150), 2)
                screen.blit(font_small.render("Место", True, (255, 255, 0)), (160, 120))
                screen.blit(font_small.render("Имя игрока", True, (255, 255, 0)), (300, 120))
                screen.blit(font_small.render("Счёт", True, (255, 255, 0)), (580, 120))
                
                y_offset = 160
                for idx, res in enumerate(sorted_results[:10]):
                    screen.blit(font_small.render(f"# {idx + 1}", True, const.UI_COLOR), (160, y_offset))
                    screen.blit(font_small.render(res['name'], True, const.UI_COLOR), (300, y_offset))
                    screen.blit(font_small.render(str(res['score']), True, const.UI_COLOR), (580, y_offset))
                    y_offset += 32
                    
            btn_back_results.rect.y = 520
            
        btn_back_results.draw(screen, font_medium)

    elif state == "SETTINGS":
        title = font_large.render("Настройки", True, const.UI_COLOR)
        screen.blit(title, (const.WIDTH//2 - title.get_width()//2, 80))
        vol_text = font_medium.render(f"Громкость: {int(volume * 100)}%", True, const.UI_COLOR)
        screen.blit(vol_text, (const.WIDTH//2 - vol_text.get_width()//2, 180))
        btn_vol_minus.draw(screen, font_medium)
        btn_vol_plus.draw(screen, font_medium)
        btn_back.draw(screen, font_medium)

    elif state == "MODE_SELECT":
        title = font_large.render("Выберите режим", True, const.UI_COLOR)
        screen.blit(title, (const.WIDTH//2 - title.get_width()//2, 80))
        btn_mode_clicker.draw(screen, font_medium)
        btn_mode_tracking.draw(screen, font_medium)
        btn_back.draw(screen, font_medium)

    elif state == "DIFF_SELECT":
        title = font_large.render("Сложность", True, const.UI_COLOR)
        screen.blit(title, (const.WIDTH//2 - title.get_width()//2, 50))
        for btn in diff_buttons: btn.draw(screen, font_medium)
        btn_diff_back.draw(screen, font_medium)

    elif state == "GAME_CLICKER":
        top_bar = pygame.Rect(0, 0, const.WIDTH, 50)
        pygame.draw.rect(screen, (20, 20, 20), top_bar)
        timer_text = font_medium.render(f"Время: {time_left:.1f}", True, const.UI_COLOR)
        score_text = font_medium.render(f"Счёт: {int(score)}", True, const.UI_COLOR)
        screen.blit(timer_text, (20, 5))
        screen.blit(score_text, (const.WIDTH - score_text.get_width() - 20, 5))
        
        for t in targets:
            pygame.draw.circle(screen, t.color, (int(t.x), int(t.y)), t.r)
            pygame.draw.circle(screen, (255,255,255), (int(t.x), int(t.y)), t.r, 2)

    elif state == "GAME_TRACKING":
        tracking_target.update()
        if math.hypot(mouse_pos[0] - tracking_target.x, mouse_pos[1] - tracking_target.y) <= tracking_target.r:
            score += 10.0 / const.FPS
            target_color = (50, 255, 50)
        else:
            target_color = tracking_target.color
            
        pygame.draw.circle(screen, target_color, (int(tracking_target.x), int(tracking_target.y)), tracking_target.r)
        
        top_bar = pygame.Rect(0, 0, const.WIDTH, 50)
        pygame.draw.rect(screen, (20, 20, 20), top_bar)
        timer_text = font_medium.render(f"Время: {time_left:.1f}", True, const.UI_COLOR)
        score_text = font_medium.render(f"Счёт: {int(score)}", True, const.UI_COLOR)
        screen.blit(timer_text, (20, 5))
        screen.blit(score_text, (const.WIDTH - score_text.get_width() - 20, 5))

    elif state == "PAUSE":
        overlay = pygame.Surface((const.WIDTH, const.HEIGHT))
        overlay.set_alpha(150)
        overlay.fill((0, 0, 0))
        screen.blit(overlay, (0, 0))
        title = font_large.render("ПАУЗА", True, const.UI_COLOR)
        screen.blit(title, (const.WIDTH//2 - title.get_width()//2, 80))
        btn_resume.draw(screen, font_medium)
        btn_quit_menu.draw(screen, font_medium)

    elif state == "GAME_OVER":
        title = font_large.render("Раунд завершен!", True, const.UI_COLOR)
        screen.blit(title, (const.WIDTH//2 - title.get_width()//2, 80))
        score_text = font_medium.render(f"Ваш счёт: {int(score)}", True, const.UI_COLOR)
        screen.blit(score_text, (const.WIDTH//2 - score_text.get_width()//2, 160))
        prompt = font_small.render("Введите ваше имя для таблицы рекордов:", True, const.UI_COLOR)
        screen.blit(prompt, (const.WIDTH//2 - prompt.get_width()//2, 230))
        
        input_rect = pygame.Rect(const.WIDTH//2 - 150, 270, 300, 50)
        pygame.draw.rect(screen, (50, 50, 50), input_rect, border_radius=5)
        pygame.draw.rect(screen, const.UI_COLOR, input_rect, 2, border_radius=5)
        
        name_surf = font_medium.render(player_name + "_", True, (255, 255, 0))
        screen.blit(name_surf, (input_rect.x + 10, input_rect.y + 5))
        
        btn_save.draw(screen, font_medium)
        btn_skip.draw(screen, font_medium)

    pygame.display.flip()
    clock.tick(const.FPS)

pygame.quit()
sys.exit()