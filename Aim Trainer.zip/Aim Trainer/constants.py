WIDTH, HEIGHT = 800, 600
FPS = 60
ROUND_TIME = 30
RESULTS_FILE = "results.json"

BG_COLOR = (30, 30, 30)
UI_COLOR = (240, 240, 240)
BTN_COLOR = (70, 130, 180)
BTN_HOVER_COLOR = (100, 150, 200)
TEXT_COLOR = (255, 255, 255)
DANGER_COLOR = (220, 50, 50)
TARGET_COLORS = [(255, 99, 71), (144, 238, 144), (135, 206, 235), (255, 215, 0), (255, 105, 180)]

CLICKER_RADIUS = {"Лёгкий": 25, "Средний": 20, "Сложный": 15, "Эксперт": 10}
TRACKING_SPEED = {"Лёгкий": 2, "Средний": 4, "Сложный": 6, "Эксперт": 8}